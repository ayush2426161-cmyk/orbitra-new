/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { useTelemetry } from '../context/TelemetryContext';

/**
 * SpaceBackground
 * ---------------------------------------------------------------
 * Fixed full-screen layer that sits behind the whole dashboard:
 *   1. Blurred Milky Way photo (slow drift)
 *   2. Canvas with an Earth horizon, the GS-01 ground station,
 *      three orbiting satellites, and "bridge" links
 *        - ground station  <->  satellites   (uplink / downlink arches)
 *        - satellite       <->  satellite    (inter-satellite relay bridges)
 *   3. Every user action (click / tap / key press / tab change)
 *      makes the satellites manoeuvre, fires a bridge handshake
 *      (data packets travel the bridge and come back as an ACK).
 *
 * Bridge colours follow the real link state from TelemetryContext:
 *   cyan  = link OK          amber = offline
 *   red   = RF kill active (bridge is severed, packets die mid-way)
 */

type BridgeState = 'ok' | 'offline' | 'cut';

interface Sat {
  name: string;
  color: string;
  main: boolean;
  rx: number; // orbit radius as fraction of width
  ry: number; // orbit radius as fraction of height
  baseTilt: number;
  tilt: number;
  tiltTarget: number;
  theta: number;
  speed: number; // rad/s (sign = direction)
  boost: number; // extra rad/s from user actions, decays
  flash: number; // 0..1 glow when ACK received
  x: number;
  y: number;
  ang: number;
  trail: { x: number; y: number }[];
}

interface Link {
  a: number; // -1 = ground station
  b: number;
  glow: number; // 0..1
}

interface Packet {
  link: number;
  t: number; // 0..1 along link
  dir: 1 | -1;
  speed: number; // link-lengths per second
  delay: number; // seconds before it starts moving
  color: string;
  ack: boolean; // when it reaches the sat, spawn a return packet
}

interface Ripple {
  x: number;
  y: number;
  r: number;
  a: number;
  color: string;
}

const COLORS = {
  ok: '#22D3EE',
  offline: '#FBBF24',
  cut: '#F43F5E',
  purple: '#A78BFA',
  green: '#34D399',
};

const GS_ID = -1;

export function SpaceBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const { isConnected, emergencyKillActive } = useTelemetry();

  // Keep the latest link state in a ref so the animation loop never restarts.
  const bridgeRef = useRef<BridgeState>('ok');
  bridgeRef.current = emergencyKillActive ? 'cut' : isConnected ? 'ok' : 'offline';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reduced =
      typeof window.matchMedia === 'function' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let w = 0;
    let h = 0;
    let dpr = 1;
    let raf = 0;
    let last = performance.now();
    let lastAction = 0;
    let nextTarget = 0;

    const gs = { x: 0, y: 0 };

    const sats: Sat[] = [
      {
        name: 'COSMIC-1', color: COLORS.ok, main: true,
        rx: 0.40, ry: 0.30, baseTilt: -0.22, tilt: -0.22, tiltTarget: -0.22,
        theta: 0.6, speed: 0.2, boost: 0, flash: 0, x: 0, y: 0, ang: 0, trail: [],
      },
      {
        name: 'RELAY-A', color: COLORS.purple, main: false,
        rx: 0.28, ry: 0.36, baseTilt: 0.62, tilt: 0.62, tiltTarget: 0.62,
        theta: 2.7, speed: -0.15, boost: 0, flash: 0, x: 0, y: 0, ang: 0, trail: [],
      },
      {
        name: 'RELAY-B', color: COLORS.green, main: false,
        rx: 0.47, ry: 0.16, baseTilt: 0.12, tilt: 0.12, tiltTarget: 0.12,
        theta: 4.4, speed: 0.11, boost: 0, flash: 0, x: 0, y: 0, ang: 0, trail: [],
      },
    ];

    // Bridges: GS -> each satellite, plus a ring of inter-satellite links.
    const links: Link[] = [
      { a: GS_ID, b: 0, glow: 0 },
      { a: GS_ID, b: 1, glow: 0 },
      { a: GS_ID, b: 2, glow: 0 },
      { a: 0, b: 1, glow: 0 },
      { a: 1, b: 2, glow: 0 },
      { a: 2, b: 0, glow: 0 },
    ];

    const packets: Packet[] = [];
    const ripples: Ripple[] = [];

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      // Ground station sits on the crest of the Earth horizon (clear of footer / bottom nav).
      gs.x = w * 0.5;
      gs.y = h - 72;
    };

    const posOf = (i: number) => (i === GS_ID ? gs : sats[i]);

    // Quadratic "arch" curve for a link, bowing upward like a bridge.
    const curveOf = (l: Link) => {
      const A = posOf(l.a);
      const B = posOf(l.b);
      const dx = B.x - A.x;
      const dy = B.y - A.y;
      const len = Math.hypot(dx, dy) || 1;
      let nx = -dy / len;
      let ny = dx / len;
      if (ny > 0) {
        nx = -nx;
        ny = -ny;
      }
      const bow = len * (l.a === GS_ID ? 0.2 : 0.12);
      return {
        ax: A.x, ay: A.y, bx: B.x, by: B.y,
        cx: (A.x + B.x) / 2 + nx * bow,
        cy: (A.y + B.y) / 2 + ny * bow,
      };
    };

    const pointOn = (c: ReturnType<typeof curveOf>, t: number) => {
      const u = 1 - t;
      return {
        x: u * u * c.ax + 2 * u * t * c.cx + t * t * c.bx,
        y: u * u * c.ay + 2 * u * t * c.cy + t * t * c.by,
      };
    };

    const linkIndex = (a: number, b: number) =>
      links.findIndex((l) => (l.a === a && l.b === b) || (l.a === b && l.b === a));

    /* ------------------------------------------------------------------ */
    /*  User action -> satellite manoeuvre + bridge handshake              */
    /* ------------------------------------------------------------------ */
    const onAction = (px?: number, py?: number) => {
      const now = performance.now();
      if (now - lastAction < 90) return;
      lastAction = now;

      const state: BridgeState = bridgeRef.current;
      const col = COLORS[state];

      if (px !== undefined && py !== undefined && !reduced) {
        ripples.push({ x: px, y: py, r: 4, a: 0.55, color: col });
        if (ripples.length > 8) ripples.shift();
      }

      // Pick which satellite answers: nearest to the pointer, else round-robin.
      let target = nextTarget % sats.length;
      if (px !== undefined && py !== undefined) {
        let best = Infinity;
        sats.forEach((s, i) => {
          const d = Math.hypot(s.x - px, s.y - py);
          if (d < best) {
            best = d;
            target = i;
          }
        });
      }
      nextTarget = target + 1;

      // Satellites speed up and drift onto a slightly new orbit plane.
      sats.forEach((s, i) => {
        if (!reduced) {
          s.boost += Math.sign(s.speed) * (i === target ? 2.6 : 1.4);
          s.tiltTarget = s.baseTilt + (Math.random() - 0.5) * 0.55;
        }
      });

      // Bridge handshake: GS -> target satellite, ACK returns, then relay hops.
      const gl = linkIndex(GS_ID, target);
      if (gl >= 0) {
        links[gl].glow = 1;
        for (let k = 0; k < 3; k++) {
          packets.push({
            link: gl,
            t: 0,
            dir: links[gl].a === GS_ID ? 1 : -1,
            speed: 0.9,
            delay: k * 0.14,
            color: col,
            ack: k === 2,
          });
        }
      }
      if (state === 'ok') {
        sats.forEach((_, j) => {
          if (j === target) return;
          const il = linkIndex(target, j);
          if (il >= 0) {
            links[il].glow = 0.9;
            packets.push({
              link: il,
              t: 0,
              dir: links[il].a === target ? 1 : -1,
              speed: 0.7,
              delay: 0.5,
              color: sats[j].color,
              ack: false,
            });
          }
        });
      }
      while (packets.length > 60) packets.shift();
    };

    const onPointer = (e: PointerEvent) => onAction(e.clientX, e.clientY);
    const onKey = (e: KeyboardEvent) => {
      if (['Shift', 'Control', 'Alt', 'Meta'].includes(e.key)) return;
      onAction();
    };

    /* ------------------------------------------------------------------ */
    /*  Drawing helpers                                                    */
    /* ------------------------------------------------------------------ */
    const drawHorizon = (time: number, state: BridgeState) => {
      const R = Math.max(w * 0.85, 700);
      const cy = gs.y + R - 0; // crest of the arc passes through the ground station
      const grad = ctx.createLinearGradient(0, gs.y - 40, 0, h);
      grad.addColorStop(0, 'rgba(34,211,238,0.10)');
      grad.addColorStop(0.25, 'rgba(10,16,32,0.55)');
      grad.addColorStop(1, 'rgba(10,16,32,0.85)');
      ctx.beginPath();
      ctx.arc(gs.x, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();

      ctx.save();
      ctx.shadowColor = 'rgba(34,211,238,0.6)';
      ctx.shadowBlur = 18;
      ctx.strokeStyle = 'rgba(34,211,238,0.38)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();

      // Ground station dish + pulsing beacon
      const col = COLORS[state];
      const pulse = reduced ? 0.5 : (Math.sin(time * 2.2) + 1) / 2;
      ctx.beginPath();
      ctx.arc(gs.x, gs.y, 7 + pulse * 7, 0, Math.PI * 2);
      ctx.strokeStyle = col;
      ctx.globalAlpha = 0.35 * (1 - pulse * 0.7);
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.globalAlpha = 1;

      ctx.save();
      ctx.shadowColor = col;
      ctx.shadowBlur = 12;
      ctx.fillStyle = '#0A1020';
      ctx.strokeStyle = col;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(gs.x - 7, gs.y + 5);
      ctx.lineTo(gs.x, gs.y - 7);
      ctx.lineTo(gs.x + 7, gs.y + 5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(gs.x, gs.y - 7, 2.2, 0, Math.PI * 2);
      ctx.fillStyle = col;
      ctx.fill();
      ctx.restore();

      ctx.font = '9px "JetBrains Mono", ui-monospace, monospace';
      ctx.fillStyle = 'rgba(139,155,180,0.85)';
      ctx.textAlign = 'right';
      ctx.fillText('GS-01 · MMMUT', gs.x - 14, gs.y + 4);
      ctx.textAlign = 'left';
    };

    const drawLinks = (state: BridgeState) => {
      const col = COLORS[state];
      links.forEach((l) => {
        const c = curveOf(l);
        const isGs = l.a === GS_ID;
        const isMainGs = isGs && l.b === 0;

        // Resting visibility of each bridge
        let base = isMainGs ? 0.32 : isGs ? 0 : 0.12;
        if (state === 'offline') base *= 0.4;
        const alpha = Math.min(1, base + l.glow * 0.75);
        if (alpha < 0.02) return;

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(c.ax, c.ay);

        if (isGs && state === 'cut') {
          // Severed bridge: only stubs from each end, red and flickering.
          const p1 = pointOn(c, 0.32);
          const p2 = pointOn(c, 0.68);
          const flick = reduced ? 1 : 0.6 + Math.random() * 0.4;
          ctx.strokeStyle = COLORS.cut;
          ctx.globalAlpha = Math.min(1, alpha * flick);
          ctx.setLineDash([3, 5]);
          ctx.lineWidth = 1.2;
          ctx.quadraticCurveTo(
            (c.ax + p1.x) / 2 + (c.cx - (c.ax + c.bx) / 2) * 0.5,
            (c.ay + p1.y) / 2 + (c.cy - (c.ay + c.by) / 2) * 0.5,
            p1.x, p1.y,
          );
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(p2.x, p2.y);
          ctx.quadraticCurveTo(
            (c.bx + p2.x) / 2 + (c.cx - (c.ax + c.bx) / 2) * 0.5,
            (c.by + p2.y) / 2 + (c.cy - (c.ay + c.by) / 2) * 0.5,
            c.bx, c.by,
          );
          ctx.stroke();
        } else {
          ctx.strokeStyle = isGs ? col : sats[l.a === GS_ID ? l.b : l.a].color;
          ctx.globalAlpha = alpha;
          ctx.lineWidth = isGs ? 1.4 + l.glow * 1.2 : 1;
          ctx.setLineDash(isGs ? [] : [4, 6]);
          if (l.glow > 0.05) {
            ctx.shadowColor = ctx.strokeStyle;
            ctx.shadowBlur = 12 * l.glow;
          }
          ctx.quadraticCurveTo(c.cx, c.cy, c.bx, c.by);
          ctx.stroke();
        }
        ctx.restore();
      });
    };

    const drawSat = (s: Sat) => {
      // trail
      if (!reduced && s.trail.length > 2) {
        for (let i = 1; i < s.trail.length; i++) {
          const a = (i / s.trail.length) * 0.35;
          ctx.strokeStyle = s.color;
          ctx.globalAlpha = a;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(s.trail[i - 1].x, s.trail[i - 1].y);
          ctx.lineTo(s.trail[i].x, s.trail[i].y);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }

      const k = s.main ? 1.3 : 1;
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(s.ang);
      ctx.scale(k, k);
      ctx.shadowColor = s.color;
      ctx.shadowBlur = 8 + s.flash * 18;

      // solar panels
      ctx.fillStyle = s.color;
      ctx.globalAlpha = 0.85;
      ctx.fillRect(-2, -12, 4, 8);
      ctx.fillRect(-2, 4, 4, 8);
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = '#0A1020';
      ctx.fillRect(-0.5, -12, 1, 8);
      ctx.fillRect(-0.5, 4, 1, 8);
      ctx.globalAlpha = 1;

      // body
      ctx.fillStyle = '#E6F7FB';
      ctx.fillRect(-3.5, -3.5, 7, 7);
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 1;
      ctx.strokeRect(-3.5, -3.5, 7, 7);

      // antenna
      ctx.beginPath();
      ctx.moveTo(3.5, 0);
      ctx.lineTo(7, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(7.5, 0, 1.4, 0, Math.PI * 2);
      ctx.fillStyle = s.color;
      ctx.fill();
      ctx.restore();

      ctx.font = '9px "JetBrains Mono", ui-monospace, monospace';
      ctx.fillStyle = s.color;
      ctx.globalAlpha = 0.75;
      ctx.fillText(s.name, s.x + 14, s.y - 10);
      ctx.globalAlpha = 1;
    };

    /* ------------------------------------------------------------------ */
    /*  Main loop                                                          */
    /* ------------------------------------------------------------------ */
    const frame = (nowMs: number) => {
      const dt = Math.min((nowMs - last) / 1000, 0.05);
      last = nowMs;
      const time = nowMs / 1000;
      const state: BridgeState = bridgeRef.current;

      // --- update satellites
      const speedScale = reduced ? 0.15 : 1;
      sats.forEach((s) => {
        s.boost *= Math.exp(-dt * 1.4);
        s.theta += (s.speed * speedScale + s.boost) * dt;
        s.tilt += (s.tiltTarget - s.tilt) * (1 - Math.exp(-dt * 2));
        s.tiltTarget += (s.baseTilt - s.tiltTarget) * (1 - Math.exp(-dt * 0.35));
        s.flash = Math.max(0, s.flash - dt * 1.6);

        const rx = s.rx * w;
        const ry = s.ry * h;
        const ex = rx * Math.cos(s.theta);
        const ey = ry * Math.sin(s.theta);
        const ct = Math.cos(s.tilt);
        const st = Math.sin(s.tilt);
        s.x = w * 0.5 + ex * ct - ey * st;
        s.y = h * 0.4 + ex * st + ey * ct;

        const dex = -rx * Math.sin(s.theta);
        const dey = ry * Math.cos(s.theta);
        const dir = Math.sign(s.speed) || 1;
        s.ang = Math.atan2((dex * st + dey * ct) * dir, (dex * ct - dey * st) * dir);

        if (!reduced) {
          s.trail.push({ x: s.x, y: s.y });
          if (s.trail.length > 22) s.trail.shift();
        }
      });

      // --- update links / ripples
      links.forEach((l) => {
        l.glow = Math.max(0, l.glow - dt * 0.9);
      });
      for (let i = ripples.length - 1; i >= 0; i--) {
        const r = ripples[i];
        r.r += 230 * dt;
        r.a -= 1.5 * dt;
        if (r.a <= 0) ripples.splice(i, 1);
      }

      // --- update packets
      for (let i = packets.length - 1; i >= 0; i--) {
        const p = packets[i];
        if (p.delay > 0) {
          p.delay -= dt;
          continue;
        }
        p.t += p.speed * dt;
        const l = links[p.link];
        const blocked = state === 'cut' && l.a === GS_ID;
        if (blocked && p.t > 0.5) {
          const c = curveOf(l);
          const at = pointOn(c, 0.5);
          ripples.push({ x: at.x, y: at.y, r: 2, a: 0.5, color: COLORS.cut });
          packets.splice(i, 1);
          continue;
        }
        if (p.t >= 1) {
          const satIdx = p.dir === 1 ? l.b : l.a;
          if (satIdx >= 0) sats[satIdx].flash = 1;
          if (p.ack && l.a === GS_ID) {
            // Satellite answers back down the bridge
            packets.push({
              link: p.link, t: 0, dir: -1, speed: 1.1, delay: 0.12,
              color: sats[l.b].color, ack: false,
            });
            l.glow = Math.max(l.glow, 0.8);
          }
          packets.splice(i, 1);
        }
      }

      // --- draw
      ctx.clearRect(0, 0, w, h);
      drawHorizon(time, state);
      drawLinks(state);

      // packets
      packets.forEach((p) => {
        if (p.delay > 0) return;
        const l = links[p.link];
        const c = curveOf(l);
        const t = p.dir === 1 ? p.t : 1 - p.t;
        const pt = pointOn(c, Math.min(1, Math.max(0, t)));
        ctx.save();
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 14;
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 2.4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = 0.55;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      sats.forEach(drawSat);

      // ripples
      ripples.forEach((r) => {
        ctx.beginPath();
        ctx.arc(r.x, r.y, r.r, 0, Math.PI * 2);
        ctx.strokeStyle = r.color;
        ctx.globalAlpha = Math.max(0, r.a);
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.globalAlpha = 1;
      });

      // bridge status read-out, right of the ground station
      const label =
        state === 'ok' ? 'BRIDGE LINKED · COSMIC-1'
        : state === 'cut' ? 'BRIDGE SEVERED · RF KILL'
        : 'BRIDGE STANDBY · NO LINK';
      ctx.font = '9px "JetBrains Mono", ui-monospace, monospace';
      ctx.fillStyle = COLORS[state];
      ctx.globalAlpha = 0.8;
      ctx.textAlign = 'left';
      ctx.fillText(label, gs.x + 14, gs.y + 4);
      ctx.globalAlpha = 1;

      raf = requestAnimationFrame(frame);
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('pointerdown', onPointer, true);
    window.addEventListener('keydown', onKey, true);
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointerdown', onPointer, true);
      window.removeEventListener('keydown', onKey, true);
    };
  }, []);

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-[#0A1020]"
    >
      {/* Blurred Milky Way photo */}
      <img
        src="/assets/milkyway.jpg"
        alt=""
        className="absolute left-[-5%] top-[-5%] w-[110%] h-[110%] object-cover animate-milkyway-zoom"
        style={{ filter: 'blur(14px) saturate(1.15) brightness(0.75)' }}
        draggable={false}
      />
      {/* Readability overlays */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at center, rgba(10,16,32,0.25) 0%, rgba(10,16,32,0.65) 70%, rgba(10,16,32,0.9) 100%)',
        }}
      />
      <div className="absolute inset-0 tech-grid opacity-60" />
      {/* Satellites + bridges */}
      <canvas ref={canvasRef} className="absolute inset-0" />
    </div>
  );
}
